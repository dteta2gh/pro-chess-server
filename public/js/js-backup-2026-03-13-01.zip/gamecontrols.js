function newGame(){

stopClock()

game.reset()

board.start()

whiteTime = 600
blackTime = 600

updateMoveHistory()
updateClocks()

// clear board visuals
clearArrows()
removeHighlights()

// reset evaluation bar
updateEval(0)
lastEval = 0

// reset evaluation graph
if(typeof evalHistory !== "undefined"){
evalHistory = []
drawEvalGraph()
}

// reset engine
if(typeof resetEngine === "function"){
resetEngine()
}

startEvaluation()

}

function resign(){

alert("You resigned. Game over.")

newGame()

}

function exportPGN(){

let pgn = game.pgn()

let blob = new Blob([pgn], {type:"text/plain"})

let a = document.createElement("a")

a.href = URL.createObjectURL(blob)

a.download = "game.pgn"

a.click()

}

function checkGameEnd(){

    const status = document.getElementById("status")

    clearCheckHighlight()

    if(game.in_checkmate()){
        status.innerText = "Checkmate!"
        status.className = "status-mate"
        return true
    }

    if(game.in_stalemate()){
        status.innerText = "Draw by stalemate"
        status.className = "status-draw"
        return true
    }

    if(game.insufficient_material()){
        status.innerText = "Draw by insufficient material"
        status.className = "status-draw"
        return true
    }

    if(game.in_threefold_repetition()){
        status.innerText = "Draw by repetition"
        status.className = "status-draw"
        return true
    }

    if(game.in_draw()){
        status.innerText = "Draw"
        status.className = "status-draw"
        return true
    }

    return false
}

function updateTurnStatus(){

    if(game.game_over()) return

    const status = document.getElementById("status")

    if(game.in_check()){
        status.innerText = "Check!"
        status.className = "status-check"
        highlightCheckKing()
        return
    }

    clearCheckHighlight()

    if(game.turn() === 'w'){
        status.innerText = "White to move"
    }else{
        status.innerText = "Black to move"
    }

    status.className = ""
}
function beginGame(){

    playerSide = document.getElementById("playerSide").value

    newGame()
	
	initClock()
	
	startClock()

    gameStarted = true

    if(playerSide === 'b'){
        board.orientation('black')

        if(autoStockfish){
            setTimeout(playStockfish, 300)
        }
    }else{
        board.orientation('white')
    }

    updateTurnStatus()
}

function changeSide(){

    playerSide = (playerSide === 'w') ? 'b' : 'w'

    const sideSelect = document.getElementById("playerSide")
    if(sideSelect){
        sideSelect.value = playerSide
    }

    if(playerSide === 'w'){
        board.orientation('white')
    }else{
        board.orientation('black')
    }
}